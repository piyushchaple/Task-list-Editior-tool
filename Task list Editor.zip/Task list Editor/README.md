# Todo-app-in-C
## A beautiful Todo list app in C programming language

![Screenshot](https://i.imgur.com/yISUstX.png)

Try online 

[![Run on Repl.it](https://repl.it/badge/github/ShivamJoker/Todo-app-in-C)](https://repl.it/github/ShivamJoker/Todo-app-in-C)
## Features
+ Create to-dos
+ Mark as complete
+ Time of creation
+ Delete to-dos
+ Save in binary file
+ Read from binary file
